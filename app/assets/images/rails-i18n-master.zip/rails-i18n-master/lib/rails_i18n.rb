require 'rails_i18n/unicode'
require 'rails_i18n/railtie'
