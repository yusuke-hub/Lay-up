require 'rails_i18n/common_pluralizations/one_upto_two_other'

::RailsI18n::Pluralization::OneUptoTwoOther.with_locale(:'fr-CH')