require 'rails_i18n/common_pluralizations/one_two_other'

::RailsI18n::Pluralization::OneTwoOther.with_locale(:smi)