require 'rails_i18n/common_pluralizations/romanian'

::RailsI18n::Pluralization::Romanian.with_locale(:mo)